package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class TestEngine {

	public static WebDriver driver;

	protected void OpenBrowser(String URL) {
		driver = new ChromeDriver();
		driver.get(URL);
	}

	protected void open(String URL) {
		driver.get(URL);
	}

	protected void CloseBrowser() {
		driver.quit();
	}

}
