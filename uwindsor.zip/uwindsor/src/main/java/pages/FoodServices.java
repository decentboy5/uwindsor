package pages;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Iterator;
import java.util.List;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.http.message.BufferedHeader;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class FoodServices {

	static int i = 1;
	Logger logger = Logger.getLogger(FoodServices.class.getName());

	private WebDriver driver;

	public FoodServices(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//a[contains(@href,'uwindsor')]")
	List<WebElement> Alllinks_whichcontains_uwindsor;

	public void getLinks_StoreintoFile(String filename) {
		File f = new File(filename);
		if (f.exists()) {
			f.delete();
		}
		for (Iterator iterator = Alllinks_whichcontains_uwindsor.iterator(); iterator.hasNext();) {
			WebElement webElement = (WebElement) iterator.next();
			String link = webElement.getAttribute("href");
			Copydata_toTextFile(link, filename);

		}
	}

	public void VerifybrokenLinks(String FileName) {
		String url;
		File f = new File(FileName);
		try {
			BufferedReader br = new BufferedReader(new FileReader(f));
			while ((url = br.readLine()) != null) {
				verifyLinkActive(url);
			}
		} catch (Exception e) {
			System.out.println(" Exception occured in VerifybrokenLinks() method " + e.getMessage());
		}
	}

	private void Copydata_toTextFile(String link, String filename) {

		File file = new File(filename);

		FileWriter fr = null;
		BufferedWriter br = null;
		try {

			fr = new FileWriter(file, true);
			br = new BufferedWriter(fr);
			br.write(link);
			br.newLine();
			br.close();
			fr.close();
		} catch (IOException e) {
			System.out.println("Exceptioin while writing the data to text file:----" + e.getMessage());
		}
	}

	public static void verifyLinkActive(String linkUrl) {

		try {
			HttpURLConnection huc = null;
			int respCode = 200;
			huc = (HttpURLConnection) (new URL(linkUrl).openConnection());

			huc.setRequestMethod("HEAD");

			huc.connect();

			respCode = huc.getResponseCode();

			if (respCode >= 400) {
				System.out.println(linkUrl + " is a broken link");
			} else {
				//System.out.println(linkUrl + " is a valid link");
			}
		} catch (Exception e) {
			System.out.println("Check login0 ");
		}
	}

}
