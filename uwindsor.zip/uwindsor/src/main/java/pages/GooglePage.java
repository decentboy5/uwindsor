package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class GooglePage {

	private WebDriver driver;

	public GooglePage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//*[@name='q']")
	WebElement searchbox;

	@FindBy(xpath = "(//input[@value='Google Search'])[2]")
	WebElement searchButton;

	@FindBy(xpath = "(//span[text()='Uwindsor Information Office'])[1]")
	WebElement resultsConfirmationMessage;

	@FindBy(xpath = "//*[text()='www.uwindsor.ca/']")
	WebElement resultsConfirmationMessage1;

	public void Search(String text) {
		searchbox.sendKeys(text);
		searchButton.click();

	}

	public void Resultsconfirmation() {
		if (resultsConfirmationMessage.isEnabled()) {
			System.out.println("Expected results came in the resuls ");
		}
	}
}
