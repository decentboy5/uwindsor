package testcases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import pages.GooglePage;
import pages.TestEngine;
import pages.FoodServices;

public class TestCases extends TestEngine {

	@Test
	public void Testcase() throws InterruptedException {

		/* To open Browser and open google */
		OpenBrowser("https://www.google.com");

		/* Search with "uwindsor" and check the results */
		GooglePage page = new GooglePage(driver);
		page.Search("uwindsor");
		Thread.sleep(2000);
		page.Resultsconfirmation();
		Thread.sleep(2000);

		/* Navigate to "http://www.uwindsor.ca/foodservices */
		open("http://www.uwindsor.ca/foodservices/");

		/* Get all the elements which contains href and uwindsor AND store */
		FoodServices foodServices = new FoodServices(driver);
		foodServices.getLinks_StoreintoFile("result.txt");

		/*
		 * Read the links from txt file and verify the links. display in console , if
		 * any links broken
		 */
		foodServices.VerifybrokenLinks("result.txt");

		CloseBrowser();

	}

}
